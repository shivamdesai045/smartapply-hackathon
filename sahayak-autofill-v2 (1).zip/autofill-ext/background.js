// Clicking the toolbar icon opens the Sahayak window and remembers which tab to fill.
chrome.action.onClicked.addListener((tab) => {
  chrome.windows.create({ url: chrome.runtime.getURL('app.html') + '?tab=' + tab.id, type: 'popup', width: 480, height: 800 });
});
// Auto-lock: after the idle time the saved unlock key is removed, so the next use asks for the passphrase again.
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'sahayakLock') chrome.storage.session.remove('sahayakKey'); });
