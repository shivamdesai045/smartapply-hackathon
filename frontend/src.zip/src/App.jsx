import Header from "./components/Header";
import Carousel from "./components/Carousel";
import Hero from "./components/Hero";
import ServiceList from "./components/ServiceList";
import ChatBot from "./components/ChatBot";

function App() {
  return (
    <div>
      <Header />
      <div className="px-6 py-4">
        <Carousel />
      </div>
      <Hero />
      <ServiceList />
      <ChatBot />
    </div>
  );
}

export default App;