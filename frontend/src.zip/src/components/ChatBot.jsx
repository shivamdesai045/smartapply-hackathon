import { useState } from "react";

function ChatBot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: "bot", text: "Hi! I'm Sahayak Assistant. How can I help you today?" },
  ]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages([...messages, { from: "user", text: input }]);
    setInput("");
    // Placeholder bot reply — real AI logic connects here later
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { from: "bot", text: "This is a placeholder reply. AI logic coming soon!" },
      ]);
    }, 600);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-brand-600 text-white shadow-lg flex items-center justify-center text-2xl hover:bg-brand-700 z-50"
      >
        💬
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-6 w-80 max-h-[28rem] bg-white rounded-xl shadow-2xl border border-gray-200 flex flex-col z-50">
          <div className="bg-brand-600 text-white px-4 py-3 rounded-t-xl font-semibold flex justify-between items-center">
            Sahayak Assistant
            <button onClick={() => setOpen(false)} className="text-white text-lg">✕</button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`text-sm px-3 py-2 rounded-lg max-w-[85%] ${
                  msg.from === "bot"
                    ? "bg-brand-50 text-gray-800 self-start"
                    : "bg-brand-600 text-white self-end ml-auto"
                }`}
              >
                {msg.text}
              </div>
            ))}
          </div>

          <div className="flex items-center border-t border-gray-200 p-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
            <button
              onClick={sendMessage}
              className="ml-2 px-4 py-2 bg-brand-600 text-white rounded-full text-sm hover:bg-brand-700"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default ChatBot;