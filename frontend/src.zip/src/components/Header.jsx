import { useState } from "react";
import { useTranslation } from "react-i18next";

const languages = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिंदी - Hindi" },
  { code: "mr", label: "मराठी - Marathi" },
];

const navLinks = ["Home", "Services", "About"];

function Header() {
  const { t, i18n } = useTranslation();
  const [open, setOpen] = useState(false);

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    setOpen(false);
  };

  const currentLabel =
    languages.find((l) => l.code === i18n.language)?.label || "English";

  return (
    <header>
      <div className="bg-brand-700 text-white text-xs text-center py-1 px-2">
        {t("notGovtSite")}
      </div>

      <div className="flex items-center justify-between px-6 py-3 bg-white shadow-sm relative">
        <div className="flex items-center gap-2">
          <span className="text-brand-600 text-2xl">🛡️</span>
          <span className="text-xl font-bold text-brand-700">
            {t("appName")}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setOpen(!open)}
              className="px-4 py-2 rounded border border-brand-500 text-brand-700 text-sm hover:bg-brand-50 flex items-center gap-2"
            >
              {currentLabel}
              <span className="text-xs">▼</span>
            </button>

            {open && (
              <div className="absolute right-0 mt-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-50">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-brand-50 ${
                      i18n.language === lang.code
                        ? "bg-brand-50 text-brand-700 font-semibold"
                        : "text-gray-700"
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button className="px-4 py-2 rounded border border-brand-500 text-brand-700 text-sm hover:bg-brand-50">
            Login
          </button>
          <button className="px-4 py-2 rounded bg-brand-600 text-white text-sm hover:bg-brand-700">
            Register
          </button>
        </div>
      </div>

      <nav className="flex items-center justify-center gap-8 px-6 py-2 bg-gray-50 border-b border-gray-200">
        {navLinks.map((link, i) => {
          const linkClass = i === 0
            ? "text-sm font-medium text-brand-600 border-b-2 border-brand-600 pb-1"
            : "text-sm font-medium text-gray-600 hover:text-brand-600";
          return <a key={link} href="#" className={linkClass}>{link}</a>;
        })}
      </nav>
    </header>
  );
}

export default Header;